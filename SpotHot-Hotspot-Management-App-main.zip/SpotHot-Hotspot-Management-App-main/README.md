# SpotHot- An Hotspot Management App
We developed an Android app which was capable of turn on/offhotspot automatically at a given time. Turn off automatically whenbelow certain battery level. Automatically start at the boot up. Turnoff automatically Hotspot if Data Usage reach a given amount.

Some of implemented features:
- [x] starts immediately after operation system boot (you don't have to switch on manually Hotspot)
- [x] scheduler - you can define when your router will be switched off (i.e. during the night to safe the energy)
- [x] if no one is using Hotspot for configured time internet connection and tethering could be switched off
- [x] change status notifications
- [x] control data usage and deactivates tethering once the limit is exceeded
- [x] monitoring battery temperature and suspend tethering if limit exceeds
- [x] stores up to 10 WiFi tethering settings and selects one as default

All the features works best upto Android 9.
