package com.team10.mc.SpotHOT;

import org.junit.Test;

public class MyLogTest {

    @Test
    public void shouldLogSupportNullValues() {

    }

    @Test
    public void shouldContainValueAfterAdd() {

    }

    @Test
    public void shouldClearLog() {

    }

}